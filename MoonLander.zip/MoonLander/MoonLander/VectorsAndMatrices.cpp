#include "VectorsAndMatrices.h"

Matrix4::Matrix4()
	: m00_(1.0f), m01_(0.0f), m02_(0.0f), m03_(0.0f)
	, m10_(0.0f), m11_(1.0f), m12_(0.0f), m13_(0.0f)
	, m20_(0.0f), m21_(0.0f), m22_(1.0f), m23_(0.0f)
	, m30_(0.0f), m31_(0.0f), m32_(0.0f), m33_(1.0f)
{
}

Matrix4::Matrix4(const Matrix4 & rhs)
{
	m00_ = rhs.m00_;  m01_ = rhs.m01_; m02_ = rhs.m02_;	 m03_ = rhs.m03_;
	m10_ = rhs.m10_;  m11_ = rhs.m11_; m12_ = rhs.m12_;	 m13_ = rhs.m13_;
	m20_ = rhs.m20_;  m21_ = rhs.m21_; m22_ = rhs.m22_;	 m23_ = rhs.m23_;
	m30_ = rhs.m30_;  m31_ = rhs.m31_; m32_ = rhs.m32_;	 m33_ = rhs.m33_;
}

Matrix4::Matrix4(const float m00, const float m01, const float m02, const float m03,
				 const float m10, const float m11, const float m12, const float m13,
				 const float m20, const float m21, const float m22, const float m23,
				 const float m30, const float m31, const float m32, const float m33)

	: m00_(m00), m01_(m01), m02_(m02), m03_(m03)
	, m10_(m10), m11_(m11), m12_(m12), m13_(m13)
	, m20_(m20), m21_(m21), m22_(m22), m23_(m23)
	, m30_(m30), m31_(m31), m32_(m32), m33_(m33)
{
}

Matrix4 & Matrix4::operator=(const Matrix4 & rhs)
{
	m00_ = rhs.m00_; m01_ = rhs.m01_; m02_ = rhs.m02_; m03_ = rhs.m03_;
	m10_ = rhs.m10_; m11_ = rhs.m11_; m12_ = rhs.m12_; m13_ = rhs.m13_;
	m20_ = rhs.m20_; m21_ = rhs.m21_; m22_ = rhs.m22_; m23_ = rhs.m23_;
	m30_ = rhs.m30_; m31_ = rhs.m31_; m32_ = rhs.m32_; m33_ = rhs.m33_;

	return *this;
}



Vector4 Matrix4::operator*(const Vector4 & rhs) const
{
	Vector4 result;

	result.x_ = m00_ * rhs.x_ + m10_ * rhs.y_ + m20_ * rhs.z_ + m30_ * rhs.w_;
	result.y_ = m01_ * rhs.x_ + m11_ * rhs.y_ + m21_ * rhs.z_ + m31_ * rhs.w_;
	result.z_ = m02_ * rhs.x_ + m12_ * rhs.y_ + m22_ * rhs.z_ + m32_ * rhs.w_;
	result.w_ = m03_ * rhs.x_ + m13_ * rhs.y_ + m23_ * rhs.z_ + m33_ * rhs.w_;

	return result;
}

Vector4::Vector4()
	: x_(0.0f)
	, y_(0.0f)
	, z_(0.0f)
	, w_(0.0f)
{
}

Vector4::Vector4(const Vector4 &rhs)
	: x_(rhs.x_)
	, y_(rhs.y_)
	, z_(rhs.z_)
	, w_(rhs.w_)
{
}

Vector4::Vector4(const float x,
				 const float y,
				 const float z,
				 const float w)
	: x_(x)
	, y_(y)
	, z_(z)
	, w_(w)
{
}
