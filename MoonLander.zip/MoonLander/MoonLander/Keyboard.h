#pragma once
#include <SDL.h>

class Keyboard
{
	bool currentFrame[SDL_Scancode::SDL_NUM_SCANCODES];
	bool lastFrame[SDL_Scancode::SDL_NUM_SCANCODES];
public:
	Keyboard();
	~Keyboard();
	void Update();
	bool IsKeyDown(SDL_Scancode p_key);
	bool IsKeyPressed(SDL_Scancode p_key);
	bool IsKeyReleased(SDL_Scancode p_key);
	void UpdateKey(SDL_Scancode p_key, bool p_value);
};