#include "RunningState.h"


RunningState::RunningState(SDL_Renderer * p_renderer)
	:renderer(p_renderer), collisionManager(&ship,&terrain), inputHandler(*SingletonService<InputHandler>::Get()), textureHandler(*SingletonService<TextureHandler>::Get())
{
	stateName = "RunningState";
	//stateSound = SingletonService<SoundHandler>::Get()->CreateSound("Assets/Sounds/LOZFDS_Secret.wav");
	texture = textureHandler.CreateTexture("Assets/Background.png");

	sourceRect.x = 0;
	sourceRect.y = 0;
	sourceRect.h = 478;
	sourceRect.w = 512;

	destinationRect.x = 0;
	destinationRect.y = 0;
	destinationRect.h = 478;
	destinationRect.w = 512;

	//if (stateSound == nullptr)
	//{
	//	std::cout << "stateSound nullptr" << std::endl;
	//}

}

void RunningState::Enter()
{
	std::cout << "RunningState::Enter" << std::endl;
	//stateSound->Play(0);
}

bool RunningState::Update()
{
	textureHandler.Draw(texture, sourceRect, destinationRect, SDL_FLIP_NONE);

	terrain.Draw();
	if (collisionManager.CollisionHasOccured() == false)
	{
		ship.Update();
	}
	ship.Draw();

	DrawShipStats();

	collisionManager.Update();
	if (collisionManager.CollisionHasOccured() == true)
	{
		if (collisionManager.GetCollisionWasFatal() == true)
		{
			textureHandler.DrawText("Fatal Collision", 500, 300, 44);
		}
		else
		{
			textureHandler.DrawText("Safe Landing", 500, 300, 44);
		}
	}

	if (inputHandler.IsKeyPressed(SDL_SCANCODE_RETURN)) //Pause
	{
		nextState = "IdleState";
		return false;
	}

	return true;
}

void RunningState::Exit()
{
}

void RunningState::DrawShipStats()
{
	textureHandler.DrawText("Horizontal Speed", 850, 100, 24);
	textureHandler.DrawText("Vertical Speed", 850, 150, 24);
	textureHandler.DrawText("Fuel Amount", 850, 200, 24);

	std::ostringstream h;
	h.precision(3);
	h << ship.GetHorizontalVelocity() * 10; //Larger numbers looked a bit more fun, last minute change
	std::string converter = h.str();
	const char* inCharPointerFormat = converter.c_str();
	textureHandler.DrawText(inCharPointerFormat, 1100, 100, 24);

	std::ostringstream v;
	v.precision(3);
	v << ship.GetVerticalVelocity() * 10; //Larger numbers looked a bit more fun, last minute change
	converter = v.str();
	inCharPointerFormat = converter.c_str();
	textureHandler.DrawText(inCharPointerFormat, 1100, 150, 24);

	std::ostringstream f;
	f.precision(4);
	f << ship.GetFuelLevel();
	converter = f.str();
	inCharPointerFormat = converter.c_str();
	textureHandler.DrawText(inCharPointerFormat, 1100, 200, 24);
}
