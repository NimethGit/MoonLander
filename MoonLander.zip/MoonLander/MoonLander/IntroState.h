#pragma once
#include <chrono>
#include <iostream>

#include "SingletonService.h"
#include "TextureHandler.h"
#include "inputHandler.h"
#include "State.h"
#include "SDL.h"

class IntroState : public State
{
public:
	IntroState(SDL_Renderer* p_renderer);
	void Enter();
	bool Update();
	void Exit();

private:
	std::chrono::steady_clock::time_point startOfState;

	double requiredTime;
	SDL_Renderer * renderer;

	InputHandler& inputHandler;
	TextureHandler& textureHandler;
};