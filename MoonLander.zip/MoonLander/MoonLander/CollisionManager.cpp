#include "CollisionManager.h"

CollisionManger::CollisionManger(SpaceShip * spaceship, Terrain * collisionterrain)
	: ship(spaceship), terrain(collisionterrain)
{
	collisionHasOccured = false;
	collisionWasFatal = false;
	angleInRadiansAllowed = 0.26f;
}

CollisionManger::~CollisionManger()
{
	ship = nullptr;
	terrain = nullptr;
}

void CollisionManger::Update()
{
	Vector4 terrainPoint1 = { 0,0,0,1 };
	Vector4 terrainPoint2 = { 0,0,0,1 };

	for (int i = 0; i < NUMBEROFVECTORS - 1; i++)
	{
		terrainPoint1 = terrain->GetTerrainPoint(i);
		int terrainPoint1X = static_cast<int>(terrainPoint1.x_);
		int terrainPoint1Y = static_cast<int>(terrainPoint1.y_);
		terrainPoint2 = terrain->GetTerrainPoint(i+1);
		int terrainPoint2X = static_cast<int>(terrainPoint2.x_);
		int terrainPoint2Y = static_cast<int>(terrainPoint2.y_);

		if (SDL_IntersectRectAndLine(&ship->GetCollisionRect(), &terrainPoint1X, &terrainPoint1Y, &terrainPoint2X, &terrainPoint2Y) == SDL_TRUE)
		{

			if (terrainPoint1Y == terrainPoint2Y)
			{
				collisionHasOccured = true;

				float lowerVerticalVelocityBounds = -0.4f;
				if ( (ship->GetAngle() <= angleInRadiansAllowed && ship->GetAngle() >= -angleInRadiansAllowed) && ship->GetVerticalVelocity() >= lowerVerticalVelocityBounds)
				{
					collisionWasFatal = false;
				}
				else
				{
					collisionWasFatal = true;
				}
				return;
			}
			else
			{
				collisionHasOccured = true;
				collisionWasFatal = true;
				return;
			}
		}
	}
}

bool CollisionManger::CollisionHasOccured()
{
	return collisionHasOccured;
}

bool CollisionManger::GetCollisionWasFatal()
{
	return collisionWasFatal;
}
