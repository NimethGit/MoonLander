#pragma once
#include <algorithm>
#include <SDL.h>
#include "VectorsAndMatrices.h"
#include "SingletonService.h"
#include "TextureHandler.h"
#include "InputHandler.h"

const int NUMBEROFSHIPPOINTS = 17;
const float HALFPI = 1.5708f;

class SpaceShip
{
public:
	SpaceShip();
	~SpaceShip();

	void Update();
	void Draw();

	Vector4 GetCenterPosition();
	float GetFuelLevel();
	SDL_Rect& GetCollisionRect();
	float GetAngle();
	float GetHorizontalVelocity();
	float GetVerticalVelocity();

private:
	void UpdateShipPoints();
	void UpdateShipPointsWithRotation();
	void UpdateRotationMatrix();
	void UpdateTranslationMatrices();
	void UpdateVelocity();
	void CheckPlayerInput();

	Matrix4 RotationMatrix;
	Matrix4 TransposeMatrix;
	Matrix4 TransposeMatrixInverse;

	Vector4 centerPosition;
	Vector4 shipPoints[NUMBEROFSHIPPOINTS];
	Vector4 shipPointsRotated[NUMBEROFSHIPPOINTS];

	SDL_Rect collisionRect;
	float angleInRadians;
	float velocityX;
	float velocityY;
	float thrusterVelocityX;
	float thrusterVelocityY;
	float terminalVelocity;
	float gravityForce;
	float thrusterForce;
	float maxFuel;
	float currentFuelAmount;

	InputHandler& inputHandler;
	TextureHandler& textureHandler;
};