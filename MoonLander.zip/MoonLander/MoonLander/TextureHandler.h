#pragma once

#include <map>
#include <vector>
#include "SDL.h"
#include <SDL_ttf.h>

struct SDL_Renderer;
struct SDL_Texture;

class TextureHandler
{
	SDL_Renderer* m_renderer;
	std::map<const char*, SDL_Texture*> m_textures;

	//TODO: Extend with possibility to load same file
	//std::map<const char*, std::vector<SDL_Texture*, SDL_Rect>> m_textures; 

public:
	TextureHandler(SDL_Renderer* p_renderer);
	~TextureHandler();
	SDL_Texture* CreateTexture(const char* p_filePath);
	void Draw(SDL_Texture* texture, SDL_Rect sourceRect, SDL_Rect destinationRect, SDL_RendererFlip flip);
	void Draw(SDL_Texture* texture, SDL_Rect sourceRect, SDL_Rect destinationRect, double rotAngle, SDL_RendererFlip flip);
	void DrawRect(SDL_Rect* rect);

	//// ADDED RECENTLY
	TTF_Font *font;
	void DrawText(const char* text, int locationX, int locationY);
	void DrawText(const char* text, int locationX, int locationY, int size);
	void DrawText(const char* text, int locationX, int locationY, int size, Uint8 alpha);


	void DrawLine(int x1, int y1, int x2, int y2);
};
