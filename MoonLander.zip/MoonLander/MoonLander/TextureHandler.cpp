/*
I added the functionality to draw my images to the screen using this service, I also added the option to outline my SDL_Rects.
Since this is a Service I can do these things from everywhere, which helped me a ton during the early phase of the project.
The textureHandler is efficient because it only creates the texture once, if something else uses the same texture, the textureHandler will give the pointer to the already created texture.
The textureHandler also makes sure that everything is housekept, emptying lists and deleting objects. I did not use the Sprite class because of a reason I've forgot.
*/
#include "TextureHandler.h"
#include "Sprite.h"
#include <SDL.h>
#include <SDL_image.h>
#include <iostream>

TextureHandler::TextureHandler(SDL_Renderer * p_renderer)
{
	if (p_renderer == nullptr)
	{
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "No renderer sent in the SpriteHandler::Constructor %s", SDL_GetError());
	}
	m_renderer = p_renderer;


	////ADDED RECENTLY
	font = TTF_OpenFont("Assets/MoonbaseOmega.ttf", 20);
}

TextureHandler::~TextureHandler()
{
	for (auto pair : m_textures)
	{
		SDL_DestroyTexture(pair.second);
		pair.second = nullptr;
	}
	m_textures.clear();

	m_renderer = nullptr;

	////ADDED RECENTLY
	TTF_CloseFont(font);
	font = nullptr;
}

SDL_Texture * TextureHandler::CreateTexture(const char * p_filePath)
{
	auto it = m_textures.find(p_filePath); //Checks if the texture exist in our map.
	if (it == m_textures.end())	//If it doesn't, we create it and add it to our map.
	{
		SDL_Surface* surface = IMG_Load(p_filePath);
		if (surface == nullptr)
		{
			SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't load surface: %s", SDL_GetError());
			return nullptr;
		}

		SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
		SDL_FreeSurface(surface);
		m_textures[p_filePath] = texture;
		std::cout << "Texture added to TextureHandler: " << p_filePath << std::endl;

		return texture;
	}
	else
	{
		//std::cout << "Texture was already in our map " << m_textures[p_filePath] << std::endl;
		return m_textures[p_filePath];
	}
}

void TextureHandler::Draw(SDL_Texture* texture, SDL_Rect sourceRect, SDL_Rect destinationRect, SDL_RendererFlip flip)
{
	SDL_RenderCopyEx(m_renderer, texture, &sourceRect, &destinationRect, 0, 0, flip);
}

void TextureHandler::Draw(SDL_Texture* texture, SDL_Rect sourceRect, SDL_Rect destinationRect, double rotAngle, SDL_RendererFlip flip)
{
	SDL_RenderCopyEx(m_renderer, texture, &sourceRect, &destinationRect, rotAngle, 0, flip);
}

void TextureHandler::DrawRect(SDL_Rect* rect)
{
	SDL_SetRenderDrawColor(m_renderer, 0, 125, 0, 0);
	SDL_RenderDrawRect(m_renderer, rect);
	SDL_SetRenderDrawColor(m_renderer, 0, 0, 0, 0);
}

void TextureHandler::DrawText(const char* text, int locationX, int locationY)
{
	SDL_Color white = { 255,255,255 };

	SDL_Surface *textMessage = TTF_RenderText_Solid(font, text, white);
	SDL_Texture *textTexture = SDL_CreateTextureFromSurface(m_renderer, textMessage);
	int text_width = textMessage->w;
	int text_height = textMessage->h;
	SDL_FreeSurface(textMessage);

	SDL_Rect testRect = { locationX, locationY, text_width, text_height };

	SDL_RenderCopy(m_renderer, textTexture, NULL, &testRect);
	SDL_DestroyTexture(textTexture);
}

void TextureHandler::DrawText(const char* text, int locationX, int locationY, int size)
{
	SDL_Color white = { 255,255,255 };

	TTF_Font *tempFont = TTF_OpenFont("Assets/MoonbaseOmega.ttf", size);

	SDL_Surface *textMessage = TTF_RenderText_Solid(tempFont, text, white);
	SDL_Texture *textTexture = SDL_CreateTextureFromSurface(m_renderer, textMessage);
	int text_width = textMessage->w;
	int text_height = textMessage->h;
	SDL_FreeSurface(textMessage);

	SDL_Rect testRect = { locationX, locationY, text_width, text_height };

	SDL_RenderCopy(m_renderer, textTexture, NULL, &testRect);
	SDL_DestroyTexture(textTexture);

	TTF_CloseFont(tempFont);
	tempFont = nullptr;
}

void TextureHandler::DrawText(const char* text, int locationX, int locationY, int size, Uint8 alpha)
{
	SDL_Color white = { 255,255,255 };

	TTF_Font *tempFont = TTF_OpenFont("Assets/MoonbaseOmega.ttf", size);

	SDL_Surface *textMessage = TTF_RenderText_Solid(tempFont, text, white);
	SDL_Texture *textTexture = SDL_CreateTextureFromSurface(m_renderer, textMessage);
	SDL_SetTextureAlphaMod(textTexture, alpha);
	int text_width = textMessage->w;
	int text_height = textMessage->h;
	SDL_FreeSurface(textMessage);

	SDL_Rect testRect = { locationX, locationY, text_width, text_height };

	SDL_RenderCopy(m_renderer, textTexture, NULL, &testRect);
	SDL_DestroyTexture(textTexture);

	TTF_CloseFont(tempFont);
	tempFont = nullptr;
}

void TextureHandler::DrawLine(int x1, int y1, int x2, int y2)
{
	SDL_SetRenderDrawColor(m_renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
	SDL_RenderDrawLine(m_renderer, x1, y1, x2, y2);
}
