#pragma once
#include "VectorsAndMatrices.h"
#include "SingletonService.h"
#include "TextureHandler.h"

const int NUMBEROFVECTORS = 55;

class Terrain
{
public:
	Terrain();
	~Terrain();

	void Draw();
	Vector4 GetTerrainPoint(int i);

private:
	//TODO: automatically generate a level
	Vector4 terrainPoints[NUMBEROFVECTORS];

	TextureHandler& textureHandler;
};