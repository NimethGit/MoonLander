#include "Terrain.h"

Terrain::Terrain()
	: textureHandler(*SingletonService<TextureHandler>::Get())
{
	terrainPoints[0]  = Vector4(   0, 680, 0, 1);
	terrainPoints[1]  = Vector4(  40, 680, 0, 1);
	terrainPoints[2]  = Vector4(  70, 710, 0, 1);
	terrainPoints[3]  = Vector4( 120, 710, 0, 1);
	terrainPoints[4]  = Vector4( 130, 699, 0, 1);
	terrainPoints[5]  = Vector4( 135, 679, 0, 1);
	terrainPoints[6]  = Vector4( 146, 657, 0, 1);
	terrainPoints[7]  = Vector4( 173, 633, 0, 1);
	terrainPoints[8]  = Vector4( 191, 650, 0, 1);
	terrainPoints[9]  = Vector4( 225, 659, 0, 1);
	terrainPoints[10] = Vector4( 257, 670, 0, 1);
	terrainPoints[11] = Vector4( 267, 666, 0, 1);
	terrainPoints[12] = Vector4( 275, 659, 0, 1);
	terrainPoints[13] = Vector4( 291, 650, 0, 1);
	terrainPoints[14] = Vector4( 325, 650, 0, 1);
	terrainPoints[15] = Vector4( 325, 620, 0, 1);
	terrainPoints[15] = Vector4( 335, 640, 0, 1);
	terrainPoints[16] = Vector4( 370, 680, 0, 1);
	terrainPoints[17] = Vector4( 415, 680, 0, 1);
	terrainPoints[18] = Vector4( 435, 710, 0, 1);
	terrainPoints[19] = Vector4( 480, 710, 0, 1);
	terrainPoints[20] = Vector4( 489, 699, 0, 1);
	terrainPoints[21] = Vector4( 512, 680, 0, 1);
	terrainPoints[22] = Vector4( 542, 680, 0, 1);
	terrainPoints[23] = Vector4( 560, 699, 0, 1);
	terrainPoints[24] = Vector4( 580, 710, 0, 1);
	terrainPoints[25] = Vector4( 595, 710, 0, 1);
	terrainPoints[26] = Vector4( 600, 690, 0, 1);
	terrainPoints[27] = Vector4( 630, 670, 0, 1);
	terrainPoints[28] = Vector4( 675, 670, 0, 1);
	terrainPoints[29] = Vector4( 690, 645, 0, 1);
	terrainPoints[30] = Vector4( 705, 650, 0, 1);
	terrainPoints[31] = Vector4( 721, 650, 0, 1);
	terrainPoints[32] = Vector4( 755, 659, 0, 1);
	terrainPoints[33] = Vector4( 787, 666, 0, 1);
	terrainPoints[34] = Vector4( 800, 670, 0, 1);
	terrainPoints[35] = Vector4( 816, 659, 0, 1);
	terrainPoints[36] = Vector4( 857, 650, 0, 1);
	terrainPoints[37] = Vector4( 860, 657, 0, 1);
	terrainPoints[38] = Vector4( 892, 657, 0, 1);
	terrainPoints[39] = Vector4( 900, 679, 0, 1);
	terrainPoints[40] = Vector4( 913, 699, 0, 1);
	terrainPoints[41] = Vector4( 924, 710, 0, 1);
	terrainPoints[42] = Vector4( 937, 710, 0, 1);
	terrainPoints[43] = Vector4( 945, 695, 0, 1);
	terrainPoints[44] = Vector4(1003, 680, 0, 1);
	terrainPoints[45] = Vector4(1059, 680, 0, 1);
	terrainPoints[46] = Vector4(1066, 685, 0, 1);
	terrainPoints[47] = Vector4(1090, 710, 0, 1);
	terrainPoints[48] = Vector4(1130, 710, 0, 1);
	terrainPoints[49] = Vector4(1135, 699, 0, 1);
	terrainPoints[50] = Vector4(1145, 679, 0, 1);
	terrainPoints[51] = Vector4(1190, 657, 0, 1);
	terrainPoints[52] = Vector4(1200, 667, 0, 1);
	terrainPoints[53] = Vector4(1260, 667, 0, 1);
	terrainPoints[54] = Vector4(1280, 690, 0, 1);

}

Terrain::~Terrain()
{
}

void Terrain::Draw()
{
	for (int i = 0; i < NUMBEROFVECTORS-1; i++)
	{
		textureHandler.DrawLine(static_cast<int>(terrainPoints[i].x_), static_cast<int>(terrainPoints[i].y_),
				                 static_cast<int>(terrainPoints[i + 1].x_), static_cast<int>(terrainPoints[i + 1].y_));
	}
}

Vector4 Terrain::GetTerrainPoint(int i)
{
	Vector4 Results;

	if (i < NUMBEROFVECTORS && i >= 0)
	{
		return terrainPoints[i];
	}

	return Results;
}
