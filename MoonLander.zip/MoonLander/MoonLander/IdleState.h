#pragma once
#include <string>
#include <iostream>
#include <chrono>

#include "SingletonService.h"
#include "TextureHandler.h"
#include "inputHandler.h"
#include "State.h"
#include "SDL.h"

class IdleState : public State
{
public:
	IdleState(SDL_Renderer* p_renderer);
	void Enter();
	bool Update();
	void Exit();

private:
	SDL_Renderer * renderer;

	InputHandler& inputHandler;
	TextureHandler& textureHandler;
};