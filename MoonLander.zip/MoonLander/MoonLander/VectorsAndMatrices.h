#pragma once
#include <math.h>

struct Vector4
{
	Vector4();
	Vector4(const Vector4 &rhs);
	Vector4(const float x, const float y, float const z, float const w);

	float x_;
	float y_;
	float z_;
	float w_;
};

struct Matrix4
{

	Matrix4();
	Matrix4(const Matrix4 &rhs);
	Matrix4(const float m00, const float m01, const float m02, const float m03,
			const float m10, const float m11, const float m12, const float m13,
			const float m20, const float m21, const float m22, const float m23,
			const float m30, const float m31, const float m32, const float m33);

	Matrix4 &operator=(const Matrix4 &rhs);
	Vector4 operator*(const Vector4 &rhs) const;

	float m00_, m01_, m02_, m03_;
	float m10_, m11_, m12_, m13_;
	float m20_, m21_, m22_, m23_;
	float m30_, m31_, m32_, m33_;
};
