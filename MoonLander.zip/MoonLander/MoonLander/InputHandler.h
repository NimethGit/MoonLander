#pragma once
#include "Keyboard.h"

class InputHandler
{
	Keyboard m_keyboard;
public:
	bool IsKeyDown(SDL_Scancode p_key);
	bool IsKeyPressed(SDL_Scancode p_key);
	bool IsKeyReleased(SDL_Scancode p_key);

	void HandleEvents();
};