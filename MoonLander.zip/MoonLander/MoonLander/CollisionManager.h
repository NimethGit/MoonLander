#pragma once
#include <SDL.h>
#include "SpaceShip.h"
#include "Terrain.h"

class CollisionManger
{
public:
	CollisionManger(SpaceShip* ship, Terrain* terrain);
	~CollisionManger();

	void Update();
	bool CollisionHasOccured();
	bool GetCollisionWasFatal();

private:
	SpaceShip* ship;
	Terrain* terrain;

	float angleInRadiansAllowed;
	bool collisionWasFatal;
	bool collisionHasOccured;
};