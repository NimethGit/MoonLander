#pragma comment(lib, "../Dependencies/SDL2/lib/x64/SDL2.lib")
#pragma comment(lib, "../Dependencies/SDL2/lib/x64/SDL2main.lib")
#pragma comment(lib, "../Dependencies/SDL2_ttf/lib/x64/SDL2_ttf.lib")
#pragma comment(lib, "../Dependencies/SDL2_mixer/lib/x64/SDL2_mixer.lib")
#pragma comment(lib, "../Dependencies/SDL2_image/lib/x64/SDL2_image.lib")

#include <SDL.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include <SDL_image.h>

#include "iostream"

#include "SingletonService.h"
#include "InputHandler.h"
#include "TextureHandler.h"
#include "SoundHandler.h"

#include "FiniteStateMachine.h"
#include "IntroState.h"
#include "IdleState.h"
#include "RunningState.h"

#undef main

#define CHECK_FOR_LEAKS 1

const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;

int main(int argc, char *args[])
{

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not initialize SDL: %s", SDL_GetError());

	if (Mix_Init(MIX_INIT_MP3) == 0)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not initialize SDL_mixer: %s", Mix_GetError());

	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not initialize OpenAudio: %s", Mix_GetError());

	if (IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG) == 0)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not initialize IMG: %s", IMG_GetError());;

	if(TTF_Init() == -1)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not initialize TTF: %s", TTF_GetError());;

	SDL_Window* window = SDL_CreateWindow("Zelda", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_BORDERLESS);
	if (window == nullptr)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not create SDL_Window: %s", SDL_GetError());

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if (renderer == nullptr)
		SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not create SDL_Renderer: %s", SDL_GetError());

	/*
	Renderer: For a renderer to work it requires a window.
	It works basically like a collage, each frame you add things to the renderer, if you add two things in the same spot, the latter will be shown.
	The collage metaphor works really well, you can add anything from anywhere by changing texture and sourceRect
	(Imagine choosing a sportsmagazine[texture] and cutting our a car[sourceRect] that you like, and pasting it perhaps in the center, or top right corner [destinationRect])
	Once you've added everything that you want to show, you present the "collage" to the screen. It is the 2nd last thing I do in my game-loop (right before delaying the frame)
	*/


	{   //Scope to add limited lifetime for out handlers and game loop, useful when checking for memory leaks

		//Capping frame rate because we don't use a timer such as the timer in unity (Time.deltaTime()) so the movement is based on your framerate (more framerate = faster movement)
		const int FPS = 60;
		const int frameDelay = 1000 / FPS;
		Uint32 frameStart;
		int frameTime;


		//// We're always playing music. Sometimes sound effects will play "over" the background music. 
		Mix_Music *backgroundMusic = Mix_LoadMUS("Assets/Sounds/MagicalPath.ogg");

		if (backgroundMusic == nullptr)
		{
			std::cout << "Couldn't load background music" << std::endl;
		}
		else
		{
			Mix_VolumeMusic(1);
			Mix_PlayMusic(backgroundMusic, -1);
		}

		/*
		Audio works through the use of SDL_Mixer, we can play music on several channels and we can play "chunks" which are shorter sound clips.
		I load them through the use of Mix_LoadMUS and  Mix_LoadWAV since those are the file formats I had. The SoundHandler takes care of creating the sound.
		It does it in an efficient way, if we've already made the sound once we don't need to create it again. That is why we are using pointers and not objects.
		The SoundHandler also takes care of the housekeeping, the deallocation of memory. Because the SoundHandler is a "Service" everything can reach it, which is a huge convenience for us.
		*/

		InputHandler inputHandler;
		SoundHandler soundHandler;
		TextureHandler textureHandler(renderer);
		SingletonService<InputHandler>::Set(&inputHandler);
		SingletonService<SoundHandler>::Set(&soundHandler);
		SingletonService<TextureHandler>::Set(&textureHandler);

		//Setting up the finite state machine
		FiniteStateMachine finiteStateMachine;

		IntroState IntroState(renderer);
		IdleState IdleState(renderer);
		RunningState runningState(renderer);

		finiteStateMachine.AddState(&IntroState);
		finiteStateMachine.AddState(&IdleState);
		finiteStateMachine.AddState(&runningState);

		finiteStateMachine.SetState(&IntroState);



		bool runApplication = true;
		while (runApplication) //Our core game-loop
		{
			frameStart = SDL_GetTicks(); //Needed for capping the frame rate

			inputHandler.HandleEvents();
			if (inputHandler.IsKeyDown(SDL_SCANCODE_ESCAPE))
			{
				runApplication = false;
			}


			// CLEARING SCREEN
			SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
			SDL_RenderClear(renderer);

			finiteStateMachine.Update();

			// PRESENTING TO THE SCREEN
			SDL_RenderPresent(renderer);


			frameTime = SDL_GetTicks() - frameStart; //Gives us the time it took to handle this frame.
			if (frameDelay > frameTime)              //Tells us if we should delay the frame or not.
			{
				SDL_Delay(frameDelay - frameTime);
			}
		}


		Mix_FreeMusic(backgroundMusic);
		backgroundMusic = nullptr;

	}


	//Closing and terminating everything properly
	if (renderer != nullptr)
		SDL_DestroyRenderer(renderer);

	if (window != nullptr)
		SDL_DestroyWindow(window);

	TTF_Quit();
	Mix_CloseAudio();
	Mix_Quit();
	SDL_Quit();

	renderer = nullptr;
	window = nullptr;


	//// MEMORY LEAKS ////
#if CHECK_FOR_LEAKS == 1
	bool leaks = _CrtDumpMemoryLeaks();
	if (leaks == true)
	{
		std::cout << "Found leaks!" << std::endl;
	}
#endif

	return 0;
}