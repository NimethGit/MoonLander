#include "SpaceShip.h"

#define DEBUG_COLLIDER 0

SpaceShip::SpaceShip()
	:inputHandler(*SingletonService<InputHandler>::Get()), textureHandler(*SingletonService<TextureHandler>::Get())
{
	centerPosition = Vector4(100, 100, 0, 1);

	//Rocket Top Center
	shipPoints[0] = Vector4(centerPosition.x_, centerPosition.y_ - 20, 0, 1);
	//Main body
	shipPoints[1] = Vector4(centerPosition.x_ + 7, centerPosition.y_ - 8, 0, 1);
	shipPoints[2] = Vector4(centerPosition.x_ - 7, centerPosition.y_ - 8, 0, 1);
	shipPoints[3] = Vector4(centerPosition.x_ + 7, centerPosition.y_ + 10, 0, 1);
	shipPoints[4] = Vector4(centerPosition.x_ - 7, centerPosition.y_ + 10, 0, 1);
	//Thruster
	shipPoints[5] = Vector4(centerPosition.x_ + 2, centerPosition.y_+ 10, 0, 1);
	shipPoints[6] = Vector4(centerPosition.x_ - 2, centerPosition.y_+ 10, 0, 1);
	shipPoints[7] = Vector4(centerPosition.x_ + 5, centerPosition.y_+ 14, 0, 1);
	shipPoints[8] = Vector4(centerPosition.x_ - 5, centerPosition.y_+ 14, 0, 1);
	//Right Wing
	shipPoints[9] = Vector4(centerPosition.x_ + 7, centerPosition.y_ - 2, 0, 1);
	shipPoints[10] = Vector4(centerPosition.x_ + 15,centerPosition.y_ + 10, 0, 1);
	shipPoints[11] = Vector4(centerPosition.x_ + 15,centerPosition.y_ + 14, 0, 1);
	shipPoints[12] = Vector4(centerPosition.x_ + 10,centerPosition.y_ + 14, 0, 1);
	//Left Wing					  		  						  
	shipPoints[13] = Vector4(centerPosition.x_ - 7, centerPosition.y_- 2, 0, 1);
	shipPoints[14] = Vector4(centerPosition.x_ - 15,centerPosition.y_ + 10, 0, 1);
	shipPoints[15] = Vector4(centerPosition.x_ - 15,centerPosition.y_ + 14, 0, 1);
	shipPoints[16] = Vector4(centerPosition.x_ - 10,centerPosition.y_ + 14, 0, 1);

	angleInRadians = 0;

	TransposeMatrix = Matrix4(1, 0, 0, 0,
							  0, 1, 0, 0,
							  0, 0, 1, 0,
							  -centerPosition.x_, -centerPosition.y_, 0, 1);

	TransposeMatrixInverse = Matrix4(1, 0, 0, 0,
									 0, 1, 0, 0,
									 0, 0, 1, 0,
									 centerPosition.x_, centerPosition.y_, 0, 1);

	RotationMatrix = Matrix4((float)cos(angleInRadians), (float)sin(angleInRadians), 0, 0,
									 (float)-sin(angleInRadians), (float)cos(angleInRadians), 0, 0,
									 0, 0, 1, 0,
									 0, 0, 0, 1);

	collisionRect.h = 30;
	collisionRect.w = 22;
	collisionRect.x = (int)(centerPosition.x_ - 11);
	collisionRect.y = (int)(centerPosition.y_ - 13);

	maxFuel = 1000;
	currentFuelAmount = 1000;

	velocityX = 0;
	velocityY = 0;
	thrusterVelocityX = 0;
	thrusterVelocityY = 0;
	terminalVelocity = 5;
	gravityForce = 0.005f;
	thrusterForce = 0.015f;
}

SpaceShip::~SpaceShip()
{
}

void SpaceShip::Update()
{
	CheckPlayerInput();
	UpdateVelocity();

	UpdateRotationMatrix();
	UpdateTranslationMatrices();

	UpdateShipPoints();
	UpdateShipPointsWithRotation();
}

void SpaceShip::Draw()
{
#if DEBUG_COLLIDER == 1
	textureHandler.DrawRect(&collisionRect);
#endif

	//for (int i = 0; i < NUMBEROFSHIPPOINTS-1; i++) //Reorder the points to fit this formula for cleaner drawing?
	//{
	//	textureHandler.DrawLine(shipPointsRotated[i].x_, shipPointsRotated[i].y_, shipPointsRotated[i+1].x_, shipPointsRotated[i+1].y_);
	//}

	textureHandler.DrawLine((int)shipPointsRotated[0].x_ , (int)shipPointsRotated[0].y_ , (int)shipPointsRotated[1].x_ , (int)shipPointsRotated[1].y_);
	textureHandler.DrawLine((int)shipPointsRotated[0].x_ , (int)shipPointsRotated[0].y_ , (int)shipPointsRotated[2].x_ , (int)shipPointsRotated[2].y_);
	textureHandler.DrawLine((int)shipPointsRotated[1].x_ , (int)shipPointsRotated[1].y_ , (int)shipPointsRotated[3].x_ , (int)shipPointsRotated[3].y_);
	textureHandler.DrawLine((int)shipPointsRotated[2].x_ , (int)shipPointsRotated[2].y_ , (int)shipPointsRotated[4].x_ , (int)shipPointsRotated[4].y_);
	textureHandler.DrawLine((int)shipPointsRotated[3].x_ , (int)shipPointsRotated[3].y_ , (int)shipPointsRotated[4].x_ , (int)shipPointsRotated[4].y_);
	textureHandler.DrawLine((int)shipPointsRotated[5].x_ , (int)shipPointsRotated[5].y_ , (int)shipPointsRotated[7].x_ , (int)shipPointsRotated[7].y_);
	textureHandler.DrawLine((int)shipPointsRotated[6].x_ , (int)shipPointsRotated[6].y_ , (int)shipPointsRotated[8].x_ , (int)shipPointsRotated[8].y_);
	textureHandler.DrawLine((int)shipPointsRotated[7].x_ , (int)shipPointsRotated[7].y_ , (int)shipPointsRotated[8].x_ , (int)shipPointsRotated[8].y_);
	textureHandler.DrawLine((int)shipPointsRotated[9].x_ , (int)shipPointsRotated[9].y_ , (int)shipPointsRotated[10].x_, (int)shipPointsRotated[10].y_);
	textureHandler.DrawLine((int)shipPointsRotated[10].x_, (int)shipPointsRotated[10].y_, (int)shipPointsRotated[11].x_, (int)shipPointsRotated[11].y_);
	textureHandler.DrawLine((int)shipPointsRotated[11].x_, (int)shipPointsRotated[11].y_, (int)shipPointsRotated[12].x_, (int)shipPointsRotated[12].y_);
	textureHandler.DrawLine((int)shipPointsRotated[12].x_, (int)shipPointsRotated[12].y_, (int)shipPointsRotated[3].x_ , (int)shipPointsRotated[3].y_);
	textureHandler.DrawLine((int)shipPointsRotated[13].x_, (int)shipPointsRotated[13].y_, (int)shipPointsRotated[14].x_, (int)shipPointsRotated[14].y_);
	textureHandler.DrawLine((int)shipPointsRotated[14].x_, (int)shipPointsRotated[14].y_, (int)shipPointsRotated[15].x_, (int)shipPointsRotated[15].y_);
	textureHandler.DrawLine((int)shipPointsRotated[15].x_, (int)shipPointsRotated[15].y_, (int)shipPointsRotated[16].x_, (int)shipPointsRotated[16].y_);
	textureHandler.DrawLine((int)shipPointsRotated[16].x_, (int)shipPointsRotated[16].y_, (int)shipPointsRotated[4].x_ , (int)shipPointsRotated[4].y_);
}

Vector4 SpaceShip::GetCenterPosition()
{
	return centerPosition;
}

float SpaceShip::GetFuelLevel()
{
	return currentFuelAmount;
}

SDL_Rect & SpaceShip::GetCollisionRect()
{
	return collisionRect;
}

float SpaceShip::GetAngle()
{
	return angleInRadians;
}

float SpaceShip::GetHorizontalVelocity()
{
	return velocityX;
}

float SpaceShip::GetVerticalVelocity()
{
	return velocityY;
}

void SpaceShip::UpdateShipPoints()
{
	//Top Center
	shipPoints[0]  = Vector4(centerPosition.x_, centerPosition.y_ - 20, 0, 1);	
	//Main body
	shipPoints[1]  = Vector4(centerPosition.x_ +  7, centerPosition.y_ -  8, 0, 1);
	shipPoints[2]  = Vector4(centerPosition.x_ -  7, centerPosition.y_ -  8, 0, 1);
	shipPoints[3]  = Vector4(centerPosition.x_ +  7, centerPosition.y_ + 10, 0, 1);
	shipPoints[4]  = Vector4(centerPosition.x_ -  7, centerPosition.y_ + 10, 0, 1);			
	//Thruster
	shipPoints[5]  = Vector4(centerPosition.x_ +  2, centerPosition.y_ + 10, 0, 1);
	shipPoints[6]  = Vector4(centerPosition.x_ -  2, centerPosition.y_ + 10, 0, 1);
	shipPoints[7]  = Vector4(centerPosition.x_ +  5, centerPosition.y_ + 14, 0, 1);
	shipPoints[8]  = Vector4(centerPosition.x_ -  5, centerPosition.y_ + 14, 0, 1);	
	//Right Wing
	shipPoints[9]  = Vector4(centerPosition.x_ +  7, centerPosition.y_ -  2, 0, 1);
	shipPoints[10] = Vector4(centerPosition.x_ + 15, centerPosition.y_ +  8, 0, 1);
	shipPoints[11] = Vector4(centerPosition.x_ + 15, centerPosition.y_ + 14, 0, 1);
	shipPoints[12] = Vector4(centerPosition.x_ + 10, centerPosition.y_ + 14, 0, 1);
	//Left Wing
	shipPoints[13] = Vector4(centerPosition.x_ -  7, centerPosition.y_ -  2, 0, 1);
	shipPoints[14] = Vector4(centerPosition.x_ - 15, centerPosition.y_ +  8, 0, 1);
	shipPoints[15] = Vector4(centerPosition.x_ - 15, centerPosition.y_ + 14, 0, 1);
	shipPoints[16] = Vector4(centerPosition.x_ - 10, centerPosition.y_ + 14, 0, 1);

	collisionRect.x = (int)(centerPosition.x_ - 11);
	collisionRect.y = (int)(centerPosition.y_ - 13);
}

void SpaceShip::UpdateShipPointsWithRotation()
{
	for (int index = 0; index < NUMBEROFSHIPPOINTS; index++)
	{
		shipPointsRotated[index] = TransposeMatrixInverse * (RotationMatrix * ((TransposeMatrix * shipPoints[index])));
	}
}

void SpaceShip::UpdateRotationMatrix()
{
	RotationMatrix = Matrix4((float)cos(angleInRadians), (float)sin(angleInRadians), 0, 0,
							 (float)-sin(angleInRadians), (float)cos(angleInRadians), 0, 0,
							 0, 0, 1, 0,
							 0, 0, 0, 1);
}

void SpaceShip::UpdateTranslationMatrices()
{
	TransposeMatrix = Matrix4(1, 0, 0, 0,
							  0, 1, 0, 0,
							  0, 0, 1, 0,
							  -centerPosition.x_, -centerPosition.y_, 0, 1);

	TransposeMatrixInverse = Matrix4(1, 0, 0, 0,
									 0, 1, 0, 0,
									 0, 0, 1, 0,
									 centerPosition.x_, centerPosition.y_, 0, 1);
}

void SpaceShip::UpdateVelocity()
{
	velocityY -= (gravityForce + thrusterVelocityY);
	velocityX -= thrusterVelocityX;

	float velocityFactor = 0.1f;
	//float velocityFactor = 1.0f;
	centerPosition.y_ -= velocityY * velocityFactor;
	centerPosition.x_ -= velocityX * velocityFactor;
}

void SpaceShip::CheckPlayerInput()
{
	float rotationAmount = 0.03f;

	if (inputHandler.IsKeyDown(SDL_SCANCODE_D) || inputHandler.IsKeyPressed(SDL_SCANCODE_D))
	{
		angleInRadians = angleInRadians + rotationAmount;
	}

	if (inputHandler.IsKeyDown(SDL_SCANCODE_A) || inputHandler.IsKeyPressed(SDL_SCANCODE_A))
	{
		angleInRadians = angleInRadians - rotationAmount;
	}

	angleInRadians = std::clamp(angleInRadians, -HALFPI, HALFPI);

	
	if (inputHandler.IsKeyDown(SDL_SCANCODE_W))
	{
		float fuelConsumption = 0.5f;
		if (currentFuelAmount > 0)
		{
			currentFuelAmount = currentFuelAmount - fuelConsumption;
			if (currentFuelAmount < 0)
				currentFuelAmount = 0;

			thrusterVelocityX = (float)(cos(angleInRadians - HALFPI) * thrusterForce);
			thrusterVelocityY = (float)(sin(angleInRadians - HALFPI) * thrusterForce);
		}
	}
	else
	{
		thrusterVelocityX = 0;
		thrusterVelocityY = 0;
	}
}
