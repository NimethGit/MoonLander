#pragma once

template <typename T>
class SingletonService
{
private:
	static T* m_instance;
	SingletonService() {};
public:
	static void Set(T* p_instance) { m_instance = p_instance; };
	static T* Get() { return m_instance; };
};

template <typename T>
T* SingletonService<T>::m_instance = nullptr;
