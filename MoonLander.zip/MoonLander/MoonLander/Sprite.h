#pragma once

#include <SDL.h>

class Sprite
{
	SDL_Texture* texture;
	SDL_Rect sourceRect;
	SDL_Rect destinationRect;

public:
	Sprite(SDL_Texture* p_texture, int p_x, int p_y, int p_w, int p_h);
	SDL_Texture* GetTexture();
	SDL_Rect GetSourceRect();
	SDL_Rect GetDestinationRect();
};
