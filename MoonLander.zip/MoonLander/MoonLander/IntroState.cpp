#include "IntroState.h"

IntroState::IntroState(SDL_Renderer * p_renderer)
	:renderer(p_renderer), inputHandler(*SingletonService<InputHandler>::Get()), textureHandler(*SingletonService<TextureHandler>::Get())
{
	stateName = "IntroState";

	requiredTime = 2.5;
}

void IntroState::Enter()
{
	std::cout << "IntroState::Enter" << std::endl;
	startOfState = std::chrono::steady_clock::now();
}

bool IntroState::Update()
{
	textureHandler.DrawText("Moon Lander", 500, 200, 60); //Align this better, currently off-center
	textureHandler.DrawText("Made by Miguel Redondo", 480, 300, 36); //Align this better, currently off-center


	//Timer
	std::chrono::steady_clock::time_point currentTime = std::chrono::steady_clock::now();
	double elapsedTime = double(std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - startOfState).count());
	elapsedTime = (elapsedTime / 1000);

	//std::ostringstream s;
	//s << elapsedTime;
	//std::string converter = s.str();
	//const char* inCharPointerFormat = converter.c_str();
	//textureHandler.DrawText("Elapsed Time: ", 480, 600, 26);
	//textureHandler.DrawText(inCharPointerFormat, 680, 600, 26);
	//

	if (elapsedTime >= requiredTime)
	{
		std::cout << "Been in the intro state for too long, switching state to the Idle state" << std::endl;
		nextState = "IdleState";
		return false;
	}

	if (inputHandler.IsKeyPressed(SDL_SCANCODE_SPACE))
	{
		std::cout << "Spacebar is pressed in the Intro state, should switch state to the running state" << std::endl;
		nextState = "RunningState";
		return false;
	}

	return true;
}

void IntroState::Exit()
{
}
