#include "InputHandler.h"
#include <SDL.h>
#include <iostream>

bool InputHandler::IsKeyDown(SDL_Scancode p_key)
{
	return m_keyboard.IsKeyDown(p_key);
}

bool InputHandler::IsKeyPressed(SDL_Scancode p_key)
{
	return m_keyboard.IsKeyPressed(p_key);
}

bool InputHandler::IsKeyReleased(SDL_Scancode p_key)
{
	return m_keyboard.IsKeyReleased(p_key);
}

void InputHandler::HandleEvents()
{
	m_keyboard.Update();

	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		if (event.type == SDL_EventType::SDL_KEYDOWN)
		{
			m_keyboard.UpdateKey(event.key.keysym.scancode, true);
		}
		else if (event.type == SDL_EventType::SDL_KEYUP)
		{
			m_keyboard.UpdateKey(event.key.keysym.scancode, false);
		}
	}
}

//InputHandling is done through SDL_Event, SDL's own event system. We listen for specific event types, in this case we are listening for keyboard presses.
//The SDL_Event is storing all the events in a queue and what SDL_PollEvent does is to read the next event in queue. If we had some sort of mouse movement we would have needed to handle that in the HandleEvents().
//If we tried to SDL_PollEvent() somewhere else, we might miss that event because the PollEvent "eats" that event (deletes it).
//So if we had a MouseHandler and a Keyboard handler that both calls the SDL_PollEvent(), the MouseHandler might get a keyboard event and since the MouseHandler just listens for the mouse stuff it will destroy the event and
//the button press will behave like it never registered. 