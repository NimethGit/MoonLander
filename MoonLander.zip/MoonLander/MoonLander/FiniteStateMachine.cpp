#include "FiniteStateMachine.h"

/*
So our FSM has a currentState whose Update() we run every frame. That function returns a bool, which tells us if we should switch state or not.
If it tells us to switch, we will go into the current state and look at which state we should go to next.
We do that by running the state's NextState()-function which returns the name of the new state(a std::string).
We then run the FSM's internal SwitchState()-function and check if we even have a state with that name added to our list of states.
If we do, then we call the Exit() function of our current state, then call the Enter()-function of the new state.
*/

FiniteStateMachine::FiniteStateMachine() : m_currentState(nullptr)
{
}

FiniteStateMachine::~FiniteStateMachine()
{
}

void FiniteStateMachine::SwitchState(std::string p_state)
{
	for (State* state : m_states)
	{
		if (state->GetName() == p_state) 
		{
			if (m_currentState != nullptr)
				m_currentState->Exit();    //Exit the previous state.
			m_currentState = state;        //change the current state (pointer to a state)
			m_currentState->Enter();       //run that state's Enter()-function. 
			return;
		}
	}
	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not switch from %s to %s", m_currentState->GetName().c_str(), p_state.c_str());
}

void FiniteStateMachine::Update()
{
	if (m_currentState == nullptr)
		return;

	if (m_currentState->Update() == false) //Run that state's Update()-function and see if we should switch state. 
	{
		SwitchState(m_currentState->NextState());
	}
}

void FiniteStateMachine::AddState(State * p_state)
{
	if (p_state == nullptr)
		return;

	m_states.push_back(p_state);
}

void FiniteStateMachine::RemoveState(State * p_state)
{
	if (p_state == nullptr)
		return;

	for (int i = 0; i < m_states.size(); i++)
	{
		if (m_states[i] == p_state)
		{
			if (m_currentState != nullptr)
			{
				if (m_currentState == m_states[i])
				{
					m_currentState->Exit();
					m_currentState = nullptr;
				}
			}
			m_states.erase(m_states.begin() + i);
			return;
		}
	}
}

void FiniteStateMachine::SetState(State * p_state)
{
	for (State* state : m_states)
	{
		if (state == p_state)
		{
			if (m_currentState != nullptr)
			{
				m_currentState->Exit();
			}
			m_currentState = state; 
			m_currentState->Enter();
			return;
		}
	}
	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not set state: %s", p_state->GetName().c_str());
}

void FiniteStateMachine::SetState(std::string p_state)
{
	for (State* state : m_states)
	{
		if (state->GetName() == p_state)
		{
			if (m_currentState != nullptr)
			{
				m_currentState->Exit();
			}
			m_currentState = state;
			m_currentState->Enter();
			return;
		}
	}
	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Could not set state. Did you type the correct name?: %s", p_state.c_str());
}
