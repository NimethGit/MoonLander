#include "Sprite.h"

Sprite::Sprite(SDL_Texture * p_texture, int p_x, int p_y, int p_w, int p_h)
{
	texture = p_texture;
	sourceRect.x = p_x;
	sourceRect.y = p_y;
	sourceRect.w = p_w;
	sourceRect.h = p_h;

	destinationRect.x = 0;
	destinationRect.y = 0;
	destinationRect.w = 16;
	destinationRect.h = 16;
}

SDL_Texture * Sprite::GetTexture()
{
	return texture;
}

SDL_Rect Sprite::GetSourceRect()
{
	return sourceRect;
}

SDL_Rect Sprite::GetDestinationRect()
{
	return destinationRect;
}
