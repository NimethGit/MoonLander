#include "Keyboard.h"
#include <iostream>

Keyboard::Keyboard()
{
	for (int i = 0; i < SDL_Scancode::SDL_NUM_SCANCODES; i++)
	{
		lastFrame[i] = 0;
		currentFrame[i] = 0;
	}
}

Keyboard::~Keyboard()
{
}

void Keyboard::Update()
{
	for (int i = 0; i < SDL_Scancode::SDL_NUM_SCANCODES; i++)
	{
		lastFrame[i] = currentFrame[i];
	}
}

bool Keyboard::IsKeyDown(SDL_Scancode p_key)
{
	return currentFrame[p_key];
}

bool Keyboard::IsKeyPressed(SDL_Scancode p_key)
{
	return (lastFrame[p_key] == false && currentFrame[p_key] == true);
}

bool Keyboard::IsKeyReleased(SDL_Scancode p_key)
{
	return (lastFrame[p_key] == true && currentFrame[p_key] == false);
}

void Keyboard::UpdateKey(SDL_Scancode p_key, bool p_value)
{
	lastFrame[p_key] = currentFrame[p_key];
	currentFrame[p_key] = p_value;
}
