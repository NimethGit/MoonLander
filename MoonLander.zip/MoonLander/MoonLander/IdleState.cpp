#include "IdleState.h"

IdleState::IdleState(SDL_Renderer * p_renderer)
	:renderer(p_renderer), inputHandler(*SingletonService<InputHandler>::Get()), textureHandler(*SingletonService<TextureHandler>::Get())
{
	stateName = "IdleState";
}

void IdleState::Enter()
{
	std::cout << "IdleState::Enter" << std::endl;
}

bool IdleState::Update()
{
	textureHandler.DrawText("Press SPACEBAR to Start", 480, 300, 36);

	if (inputHandler.IsKeyPressed(SDL_SCANCODE_SPACE))
	{
		std::cout << "Spacebar is pressed in the Idle state, should switch state to the running state" << std::endl;
		nextState = "RunningState";
		return false;
	}

	return true;
}

void IdleState::Exit()
{
}
