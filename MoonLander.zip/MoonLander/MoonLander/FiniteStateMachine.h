#pragma once
#include <vector>
#include <string>

#include "State.h"
#include <SDL_log.h>
#include <SDL_error.h>

class FiniteStateMachine
{
	std::vector<State*> m_states;
	State* m_currentState;
	void SwitchState(std::string p_state);
public:
	FiniteStateMachine();
	~FiniteStateMachine();
	void Update();
	void AddState(State* p_state);
	void RemoveState(State* p_state);
	void SetState(State* p_state);	//handles the switching of states from outside of a state.
	void SetState(std::string p_state); //handles the switching of states from outside of a state.
};