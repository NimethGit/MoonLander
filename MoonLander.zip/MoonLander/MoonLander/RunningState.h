#pragma once
#include <string>
#include <chrono>
#include <iostream>
#include <sstream>

#include "SingletonService.h"
#include "SoundHandler.h"
#include "Sound.h"
#include "TextureHandler.h"
#include "inputHandler.h"
#include "State.h"
#include "SpaceShip.h"
#include "Terrain.h"
#include "CollisionManager.h"
#include "SDL.h"

struct SDL_Renderer;

class RunningState : public State
{
public:
	RunningState(SDL_Renderer* p_renderer);
	void Enter();
	bool Update();
	void Exit();

private:
	void DrawShipStats();

	SDL_Renderer * renderer;
	Sound* stateSound;
	SDL_Texture* texture;
	SDL_Rect sourceRect;
	SDL_Rect destinationRect;

	SpaceShip ship;
	Terrain terrain;
	CollisionManger collisionManager;

	InputHandler& inputHandler;
	TextureHandler& textureHandler;
};